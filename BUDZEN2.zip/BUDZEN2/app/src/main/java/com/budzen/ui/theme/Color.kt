package com.budzen.ui.theme

import androidx.compose.ui.graphics.Color

val BudzenBlue = Color(0xFF0474D4)
val BudzenGold = Color(0xFFF7D700)
val BudzenGray = Color(0xFF5F5F5F)